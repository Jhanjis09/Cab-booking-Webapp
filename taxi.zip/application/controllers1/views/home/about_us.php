
<div class="cp_inner-banner">
<img src="<?php  echo base_url();?>assets/images/inner-banner-img-02.jpg" alt="">

<div class="cp-inner-banner-holder">
<div class="container">
<h2>About Us</h2>

<!--ul class="breadcrumb">
<li><a href="index.html">Home</a></li>
<li class="active">About Us</li>
</ul-->
</div>
</div>
<div class="animate-bus">
<img src="<?php  echo base_url();?>assets/images/animate-bus2.png" alt="">
</div>
</div>


<div id="cp-main-content">

<section class="cp-testimonial-section2 pd-tb80">
<div class="container">

<div class="cp-tabs-holder">
<p>Melbourne13cab is one of the leading Cabs in Melbourne for ,<b>door-to-door personal transport ,
First Choice Drivers , Melbourne Airport transfers , parcel delivery, Silver Service , station
wagons , transport solutions for businesses.</b> We have built a tradition of high quality services .
We have our own commercial vehicles &amp; Luxury Cabs in excellent condition.

<br> <br>
Melbourne13Cab services has got a strong fleet to support the Cab hire services in Melbourne.
Our fleet includes a wide variety of vehicles from various brands &amp; makes. The users can select
the desired brand with all the required amenities and have a comfortable &amp; convenient cab
experience with our Melbourne Cab hire services. We render our car hire services to many
business verticals apart from individual users. It has got a team to plan your travel and make it
memorable.


<br><br>
Planning a personal cab trip in Melbourne with your family or friends? Melbourne13Cab
services can help you select your dream destination and make it even more memorable by
offering you the best discounts and special offers.

<br><br>
<strong>Select from large number of holiday destinations and book your CAB.</strong>
<br><br>
We believe in realizing the dreams of our customers. When an international tourist seeks a trip
to MELBOURNE, he / she has some specific image of Melbourne. The person wants to witness
the fascinating stories he / she has heard about Melbourne. Moreover, this is the reason he /
she chooses to visit Melbourne.

<br><br>


<b>Motto :</b> Provide a good and best service to our customer is prime motto of Melbourne13cab.
<br><br>
<strong>Why book with Airport Melbourne Taxi Service?</strong>
<p class="ph_space"> <i class="fa fa-long-arrow-right" aria-hidden="true"></i> On time performance guaranteed.</p>
<p class="ph_space"> <i class="fa fa-long-arrow-right" aria-hidden="true"></i> Latest fleet of vehicles.</p>
<p class="ph_space"> <i class="fa fa-long-arrow-right" aria-hidden="true"></i>  Round the clock availability.</p>
<p class="ph_space"> <i class="fa fa-long-arrow-right" aria-hidden="true"></i> Fully reliable and affordable taxi service.</p>
<p class="ph_space"> <i class="fa fa-long-arrow-right" aria-hidden="true"></i> Professionally trained and knowledgeable drivers.</p>
<p class="ph_space"> <i class="fa fa-long-arrow-right" aria-hidden="true"></i> Providing door to door transportation across Melbourne and nearby suburbs</p>

</p>



</div>
</div>
</section>
</div>
