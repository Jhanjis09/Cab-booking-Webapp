<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="page-header">
				<h1><?php  echo $msg; ?></h1>
			</div>
			
		</div>
	</div><!-- .row -->
</div><!-- .container -->
