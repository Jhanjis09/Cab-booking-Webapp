<div class="cp_inner-banner">
<img src="<?php  echo base_url();?>assets/images/inner-banner-img-02.jpg" alt="">

<div class="cp-inner-banner-holder">
<div class="container">
<h2>Our Services</h2>


</div>
</div>
<div class="animate-bus">
<img src="<?php  echo base_url();?>assets/images/animate-bus2.png" alt="">
</div>
</div>

<div id="cp-main-content">

<section class="cp-taxi-section pd-tb80">
<div class="container">
<div class="cp-tabs-holder">


<div class="row">
<div class="col-md-4 col-sm-6">

<article class="cp-taxi-holder">
<figure class="cp-thumb">
<img src="<?php  echo base_url();?>assets/images/taxi-img-01.jpg" alt="">
</figure>
<div class="cp-text">
<h3>Automated taxi cab bookings</h3>
<p>If you book taxi cabs regularly, Melbourne13CAB automated booking services will suit you.</p>
</ul>
<a href="#" class="cp-btn-style1">Read More</a>
</div>
</article>
</div>
<div class="col-md-4 col-sm-6">

<article class="cp-taxi-holder">
<figure class="cp-thumb">
<img src="<?php  echo base_url();?>assets/images/taxi-img-02.jpg" alt="">
</figure>
<div class="cp-text">
<h3>Door-to-door personal transport</h3>
<p>Melbourne13CAB perfectly deliver an efficient and personalised service.</p>
<a href="#" class="cp-btn-style1">Read More</a>
</div>
</article>
</div>
<div class="col-md-4 col-sm-6">

<article class="cp-taxi-holder">
<figure class="cp-thumb">
<img src="<?php  echo base_url();?>assets/images/taxi-img-03.jpg" alt="">
</figure>
<div class="cp-text">
<h3>First Choice Drivers</h3>
<p>Melbourne13CAB First Choice Drivers are experienced Taxi Cab Drivers who have exemplary</p>
<a href="#" class="cp-btn-style1">Read More</a>
</div>
</article>
</div>
<div class="col-md-4 col-sm-6">

<article class="cp-taxi-holder">
<figure class="cp-thumb">
<img src="<?php  echo base_url();?>assets/images/taxi-img-04.jpg" alt="">
</figure>
<div class="cp-text">
<h3>Melbourne Airport transfers</h3>
<p>Need to get to Melbourne Airport? Whether you're arriving at or departing from Melbourne Airport, </p>
</ul>
<a href="#" class="cp-btn-style1">Read More</a>
</div>
</article>
</div>
<div class="col-md-4 col-sm-6">

<article class="cp-taxi-holder">
<figure class="cp-thumb">
<img src="<?php  echo base_url();?>assets/images/taxi-img-05.jpg" alt="">
</figure>
<div class="cp-text">
<h3>Silver Service </h3>
<p>Let’s do business with Melbourne13CAB Silver Service. The Melbourne13CAB Silver Service taxi </p>
<a href="#" class="cp-btn-style1">Read More</a>
</div>
</article>
</div>
<div class="col-md-4 col-sm-6">

<article class="cp-taxi-holder">
<figure class="cp-thumb">
<img src="<?php  echo base_url();?>assets/images/taxi-img-06.jpg" alt="">
</figure>
<div class="cp-text">
<h3>Station wagons</h3>
<p>Whether you’re transporting luggage, a fold up wheelchair, a walker or a bike, Melbourne13CAB</p>
<a href="#" class="cp-btn-style1">Read More</a>
</div>
</article>
</div>
<div class="col-md-4 col-sm-6">

<article class="cp-taxi-holder">
<figure class="cp-thumb">
<img src="<?php  echo base_url();?>assets/images/taxi-img-07.jpg" alt="">
</figure>
<div class="cp-text">
<h3>Transport solutions for businesses</h3>
<p>The Melbourne13CAB Transport Solutions team will work closely with your business</p>
<a href="#" class="cp-btn-style1">Read More</a>
</div>
</article>
</div>
<div class="col-md-4 col-sm-6">

<article class="cp-taxi-holder">
<figure class="cp-thumb">
<img src="<?php  echo base_url();?>assets/images/taxi-img-08.jpg" alt="">
</figure>
<div class="cp-text">
<h3>Parcel Delivery </h3>
<p>With more than 2500 taxi cabs in its network, Melbourne13cab can deliver your parcel to its</p>
<a href="#" class="cp-btn-style1">Read More</a>
</div>
</article>
</div>
</div>


</div>
</div>
</section>


</div>

