<div class="cp_inner-banner">
<img src="<?php  echo base_url();?>assets/images/inner-banner-img-08.jpg" alt="">

<div class="cp-inner-banner-holder">
<div class="container">
<h2>Contact Us</h2>


</div>
</div>
<div class="animate-bus">
<img src="<?php  echo base_url();?>assets/images/animate-bus2.png" alt="">
</div>
</div>


<div id="cp-main-content">

<section class="cp-contact-us-section pd-tb80">
<div class="container">

<div class="cp-contact-inner-holder">

<p>Please note that we can only respond to general enquiries during business hours and, if your enquiry is lodged outside of business hours, it will not be actioned until the next business day.</p>

<div class="cp-get-in-outer">
<div class="row">
<div class="col-md-4 col-sm-4">
<div class="inner-holder">
<i class="fa fa-paper-plane"></i>
<a href="#">info@melbourne13cab.com</a>
</div>
</div>
<div class="col-md-4 col-sm-4">
<div class="inner-holder">
<i class="fa fa-map-marker"></i>
<p>Melbourne-3000 , Aus</p>
</div>
</div>
<div class="col-md-4 col-sm-4">
<div class="inner-holder">
<i class="fa fa-phone"></i>
<p>	+61-425213648</p>
</div>
</div>
</div>
</div>

<div class="cp-form-box cp-form-box2">
<h3>General Enquiry Form</h3>
<form action="save_contact" method="post">
<div class="row">
<div class="col-md-6 col-sm-6">
<div class="inner-holder">
<input type="text" placeholder="Full Name" name="name" required="">
</div>
<div class="inner-holder">
<input type="text" placeholder="Phone Number" name="num" required="">
</div>
<div class="inner-holder">
<input type="text" placeholder="Email Address" name="email" >
</div>
</div>
<div class="col-md-6 col-sm-6">

<div class="inner-holder">
<textarea placeholder="Comment" name="comment" required></textarea>
</div>
<div class="inner-holder">
<button type="submit" class="btn-submit" value="Submit">Submit Enquiry</button>
</div>
</div>

</div>
</form>
</div>
</div>
</div>
</section>
</div>
