<div class="cp_banner">
<div class="owl-carousel" id="cp_banner-slider">
	<div class="item">
	
		<img src="<?php  echo base_url();?>assets/images/banner-img-01.jpg" alt="">
		<div class="cp-banner-caption">
		<div class="container">
			<div class="row">
			<div class="col-md-2 col-sm-1 hidden-xs">&nbsp;</div>
				<div class="col-md-6 col-sm-6 col-xs-12">
				<div class="banner-inner-holder">
				<h2>Most Trusted  Cab Company  in Victoria (Melbourne) </h2>
<!--				<a href="#" title="" class="Discover">Discover More +</a>-->
				</div>
				</div>
				<div class="col-md-4 col-sm-5 col-xs-12">
					
				</div>
				<div class="col-md-2 col-sm-1 hidden-xs">&nbsp;</div>
			</div>
		</div>
		</div>
	</div>
	<div class="item">
	<img src="<?php  echo base_url();?>assets/images/banner-img-02.jpg" alt="">
			<div class="cp-banner-caption">
			<div class="container">
			<div class="row">
			<div class="col-md-2 col-sm-1 hidden-xs">&nbsp;</div>
				<div class="col-md-6 col-sm-6 col-xs-12">
				<div class="banner-inner-holder">
				<h2>Most Trusted  Cab Company  in Victoria (Melbourne) </h2>
<!--				<a href="#" title="" class="Discover">Discover More +</a>-->
				</div>
				</div>
				<div class="col-md-4 col-sm-5 col-xs-12">
					
				</div>
				<div class="col-md-2 col-sm-1 hidden-xs">&nbsp;</div>
			</div>
		</div>
			</div>
	</div>
	<div class="item">
	<img src="<?php  echo base_url();?>assets/images/banner-img-03.jpg" alt="">
		<div class="cp-banner-caption">
			<div class="container">
			<div class="row">
			<div class="col-md-2 col-sm-1 hidden-xs">&nbsp;</div>
				<div class="col-md-6 col-sm-6 col-xs-12">
				<div class="banner-inner-holder">
				<h2>Most Trusted  Cab Company  in Victoria (Melbourne) </h2>
<!--				<a href="#" title="" class="Discover">Discover More +</a>-->
				</div>
				</div>
				<div class="col-md-4 col-sm-5 col-xs-12">
					
				</div>
				<div class="col-md-2 col-sm-1 hidden-xs">&nbsp;</div>
			</div>
		</div>
		</div>
	</div>
	
</div>
<div class="top-socal-icon">
	<a href="#" title=""><i class="fa fa-facebook" aria-hidden="true"></i></a>
	<a href="#" title=""><i class="fa fa-google-plus" aria-hidden="true"></i></a>
	<a href="#" title=""><i class="fa fa-twitter" aria-hidden="true"></i></a>
	<a href="#" title=""><i class="fa fa-linkedin" aria-hidden="true"></i></a>
</div>

<span class="scroll-btn">
	<a href="#online_booking-main">
		<span class="mouse">
			<span>
			</span>
		</span>
	</a>
  <p>Book now</p>

</span>
</div>
    
    <div class="clearfix"></div>   

<form id="resetPassword" name="resetPassword" method="post" action="<?php echo base_url();?>welcome/ForgotPassword" onsubmit ='return validate()'>
                    <table class="table table-bordered table-hover table-striped">
                        <tbody>
                        <tr>
                            <td>Enter Email: </td>
                            <td>
                                <input type="email" name="email" id="email" style="width:250px" required>
                            </td>
                            <td><input type = "submit" value="submit" class="button"></td>
                        </tr>

                        </tbody>               </table></form>